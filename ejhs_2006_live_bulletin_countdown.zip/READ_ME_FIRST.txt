EJHS Class of 2006 Live Reunion Countdown

This folder contains a live countdown website.

FREE OPTION: GitHub Pages
1. Go to github.com and sign in or create a free account.
2. Tap the + button and create a new repository.
3. Name it: ejhs-2006-reunion-countdown
4. Upload index.html from this folder.
5. Go to Settings > Pages.
6. Under Branch, choose main, then /root, then Save.
7. GitHub will give you a public link you can post on Facebook.

The countdown is set for July 18, 2026 at 6:30 PM Central time.
